package com.mycompany.assignment2v2;

/**
 * Title: Assignment2 Author: Yin Zhanpeng Date: 29/3/2024 File Name:
 * Assignment2
 *
 * <p>
 * Program Description:</p>
 * <p>
 * This program simulates the weekly and monthly notifications for customers
 * subscribed to magazines and supplements. It allows user interactions for
 * managing subscriptions and customer information.</p>
 *
 * <p>
 * Assumptions/Conditions:</p>
 * <ol>
 * <li>The customers have a list of Supplements and Magazines.</li>
 * <li>Supplements can be individual or included within magazines.</li>
 * <li>Magazines contain their own list of Supplements.</li>
 * <li>The program allows the user to add supplements to both magazines and
 * customers.</li>
 * <li>Paying customers have a list of associate customers.</li>
 * <li>Both the paying and associate customers have their own
 * subscriptions.</li>
 * <li>The program only simulates weekly and monthly notifications.</li>
 * <li>Associate customers of a paying customer can be removed.</li>
 * <li>Removing a paying customer also removes its associated customers.</li>
 * <li>Customers contain magazines, not the other way around.</li>
 * <li>There should be at least one paying customer.</li>
 * <li>Textual data inputs for customer names, addresses, email addresses,
 * supplement names, etc., are handled.</li>
 * <li>Payment methods are represented as strings or simple identifiers.</li>
 * <li>The GUI is designed for desktop use and is not optimized for mobile
 * devices.</li>
 * <li>Billing history is displayed in a simple tabular format.</li>
 * <li>Customer address details are limited to basic information.</li>
 * <li>The program handles a reasonable number of entities without significant
 * performance degradation.</li>
 * <li>Basic error handling is implemented for scenarios such as invalid input
 * formats and file I/O errors.</li>
 * <li>The GUI layout is implemented using JavaFX controls and layouts.</li>
 * <li>The program is developed and tested on the Java SE 8 platform using
 * NetBeans IDE.</li>
 * <li>Data persistence is achieved through serialization.</li>
 * </ol>
 */
import java.util.Scanner;

/**
 * The Display class provides methods for displaying menus and user interfaces.
 */
public class Display {

    /**
     * Displays a menu and prompts the user to choose an option.
     *
     * @return The user's choice (an integer between 1 and 10).
     */

    public static int menu() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Menu:");
        System.out.println("1. Create Magazine");
        System.out.println("2. Create Supplemt");
        System.out.println("3. Create Customer");
        System.out.println("4. Add Associate to Paying Customer");
        System.out.println("5. Print out the text of all the emails for all customers for four weeks of magazines");
        System.out.println("6. Print out the text for the end of month emails for the paying customers");
        System.out.println("7. Add a new customer to the magazine service");
        System.out.println("8. Remove an existing customer from the magazine service");
        System.out.println("9. Add supplement to customer or magazine");
        System.out.println("10. Quit");

        System.out.print("Enter your choice (1-10): ");
        int choice = scanner.nextInt();

        // Validate input
        while (choice < 1 || choice > 10) {
            System.out.println("Invalid choice. Please enter a number between 1 and10.");
            System.out.print("Enter your choice (1-10): ");
            choice = scanner.nextInt();
        }

        return choice;
    }

}
