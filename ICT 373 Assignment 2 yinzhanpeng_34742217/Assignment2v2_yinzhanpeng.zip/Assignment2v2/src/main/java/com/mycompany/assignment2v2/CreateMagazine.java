package com.mycompany.assignment2v2;

/**
 * Title: Assignment2 Author: Yin Zhanpeng Date: 29/3/2024 File Name:
 * Assignment2
 *
 * <p>
 * Program Description:</p>
 * <p>
 * This program simulates the weekly and monthly notifications for customers
 * subscribed to magazines and supplements. It allows user interactions for
 * managing subscriptions and customer information.</p>
 *
 * <p>
 * Assumptions/Conditions:</p>
 * <ol>
 * <li>The customers have a list of Supplements and Magazines.</li>
 * <li>Supplements can be individual or included within magazines.</li>
 * <li>Magazines contain their own list of Supplements.</li>
 * <li>The program allows the user to add supplements to both magazines and
 * customers.</li>
 * <li>Paying customers have a list of associate customers.</li>
 * <li>Both the paying and associate customers have their own
 * subscriptions.</li>
 * <li>The program only simulates weekly and monthly notifications.</li>
 * <li>Associate customers of a paying customer can be removed.</li>
 * <li>Removing a paying customer also removes its associated customers.</li>
 * <li>Customers contain magazines, not the other way around.</li>
 * <li>There should be at least one paying customer.</li>
 * <li>Textual data inputs for customer names, addresses, email addresses,
 * supplement names, etc., are handled.</li>
 * <li>Payment methods are represented as strings or simple identifiers.</li>
 * <li>The GUI is designed for desktop use and is not optimized for mobile
 * devices.</li>
 * <li>Billing history is displayed in a simple tabular format.</li>
 * <li>Customer address details are limited to basic information.</li>
 * <li>The program handles a reasonable number of entities without significant
 * performance degradation.</li>
 * <li>Basic error handling is implemented for scenarios such as invalid input
 * formats and file I/O errors.</li>
 * <li>The GUI layout is implemented using JavaFX controls and layouts.</li>
 * <li>The program is developed and tested on the Java SE 8 platform using
 * NetBeans IDE.</li>
 * <li>Data persistence is achieved through serialization.</li>
 * </ol>
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * The CreateMagazine class provides methods to interactively create new
 * magazines and add them to the database.
 */
public class CreateMagazine {

    /**
     * Runs the process of creating a new magazine.
     *
     * @param database The database instance to interact with.
     */
    public static void run(Database database) {
        Scanner scanner = new Scanner(System.in);

        List<Magazine> magazines = database.getMagazines();
        displayExistingMagazines(magazines);

        if (promptForNewMagazine(scanner)) {
            String magazineName = promptForMagazineName(scanner);
            float magazineCost = promptForMagazineCost(scanner);
            List<Supplement> supplements = database.getSupplements();
            List<Supplement> selectedSupplements = selectSupplements(scanner, supplements);
            Magazine newMagazine = createMagazine(magazineName, magazineCost, selectedSupplements);
            database.addMagazine(newMagazine);
            System.out.println("New magazine added successfully.");
        } else {
            System.out.println("No new magazine added.");
        }
    }

    /**
     * Displays a list of existing magazines.
     *
     * @param magazines The list of existing magazines to display.
     */
    private static void displayExistingMagazines(List<Magazine> magazines) {
        System.out.println("Existing Magazines:");
        for (int i = 0; i < magazines.size(); i++) {
            System.out.println((i + 1) + ". " + magazines.get(i).getMagazineName());
        }
    }

    /**
     * Prompts the user to indicate whether they want to create a new magazine.
     *
     * @param scanner The Scanner object to read user input.
     * @return True if the user wants to create a new magazine, false otherwise.
     */
    private static boolean promptForNewMagazine(Scanner scanner) {
        System.out.print("Enter 'yes' if you want to create a new magazine: ");
        String input = scanner.nextLine();
        return input.equalsIgnoreCase("yes");
    }

    /**
     * Prompts the user to enter the name of the new magazine.
     *
     * @param scanner The Scanner object to read user input.
     * @return The name of the new magazine entered by the user.
     */
    private static String promptForMagazineName(Scanner scanner) {
        System.out.print("Enter the magazine name: ");
        return scanner.nextLine();
    }

    /**
     * Prompts the user to enter the cost of the new magazine.
     *
     * @param scanner The Scanner object to read user input.
     * @return The cost of the new magazine entered by the user.
     */
    private static float promptForMagazineCost(Scanner scanner) {
        System.out.print("Enter the magazine cost: ");
        float magazineCost = scanner.nextFloat();
        scanner.nextLine(); // Consume the newline character
        return magazineCost;
    }

    /**
     * Allows the user to select supplements to include in the new magazine.
     *
     * @param scanner The Scanner object to read user input.
     * @param supplements The list of available supplements to choose from.
     * @return The list of selected supplements chosen by the user.
     */
    private static List<Supplement> selectSupplements(Scanner scanner, List<Supplement> supplements) {
        System.out.println("Existing Supplements:");
        for (int i = 0; i < supplements.size(); i++) {
            System.out.println((i + 1) + ". " + supplements.get(i).getSupplementName());
        }

        System.out.print("Enter the numbers of supplements to include in the magazine (comma-separated): ");
        String input = scanner.nextLine();
        String[] supplementIndices = input.split(",");
        List<Supplement> selectedSupplements = new ArrayList<>();

        for (String index : supplementIndices) {
            try {
                int selectedIndex = Integer.parseInt(index.trim()) - 1;
                if (selectedIndex >= 0 && selectedIndex < supplements.size()) {
                    selectedSupplements.add(supplements.get(selectedIndex));
                } else {
                    System.out.println("Invalid supplement index: " + (selectedIndex + 1));
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input: " + index);
            }
        }

        return selectedSupplements;
    }

    /**
     * Creates a new Magazine object with the specified name, cost, and selected
     * supplements.
     *
     * @param magazineName The name of the new magazine.
     * @param magazineCost The cost of the new magazine.
     * @param selectedSupplements The list of selected supplements to include in
     * the magazine.
     * @return The newly created Magazine object.
     */
    private static Magazine createMagazine(String magazineName, float magazineCost, List<Supplement> selectedSupplements) {
        return new Magazine(magazineName, magazineCost, selectedSupplements);
    }
}
