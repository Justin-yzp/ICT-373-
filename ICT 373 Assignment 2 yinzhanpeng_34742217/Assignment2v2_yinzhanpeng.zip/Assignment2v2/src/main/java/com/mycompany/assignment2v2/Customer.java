package com.mycompany.assignment2v2;

/**
 * Title: Assignment2 Author: Yin Zhanpeng Date: 29/3/2024 File Name:
 * Assignment2
 *
 * <p>
 * Program Description:</p>
 * <p>
 * This program simulates the weekly and monthly notifications for customers
 * subscribed to magazines and supplements. It allows user interactions for
 * managing subscriptions and customer information.</p>
 *
 * <p>
 * Assumptions/Conditions:</p>
 * <ol>
 * <li>The customers have a list of Supplements and Magazines.</li>
 * <li>Supplements can be individual or included within magazines.</li>
 * <li>Magazines contain their own list of Supplements.</li>
 * <li>The program allows the user to add supplements to both magazines and
 * customers.</li>
 * <li>Paying customers have a list of associate customers.</li>
 * <li>Both the paying and associate customers have their own
 * subscriptions.</li>
 * <li>The program only simulates weekly and monthly notifications.</li>
 * <li>Associate customers of a paying customer can be removed.</li>
 * <li>Removing a paying customer also removes its associated customers.</li>
 * <li>Customers contain magazines, not the other way around.</li>
 * <li>There should be at least one paying customer.</li>
 * <li>Textual data inputs for customer names, addresses, email addresses,
 * supplement names, etc., are handled.</li>
 * <li>Payment methods are represented as strings or simple identifiers.</li>
 * <li>The GUI is designed for desktop use and is not optimized for mobile
 * devices.</li>
 * <li>Billing history is displayed in a simple tabular format.</li>
 * <li>Customer address details are limited to basic information.</li>
 * <li>The program handles a reasonable number of entities without significant
 * performance degradation.</li>
 * <li>Basic error handling is implemented for scenarios such as invalid input
 * formats and file I/O errors.</li>
 * <li>The GUI layout is implemented using JavaFX controls and layouts.</li>
 * <li>The program is developed and tested on the Java SE 8 platform using
 * NetBeans IDE.</li>
 * <li>Data persistence is achieved through serialization.</li>
 * </ol>
 */
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

/**
 * The Customer class represents a customer who can subscribe to magazines and
 * supplements.
 */
public class Customer implements Serializable {

    private String name;// The name of the customer
    private String email;// The email address of the customer.
    private List<Magazine> magazines;// The list of magazines subscribed by the customer.
    private List<Supplement> supplements;// The list of supplements subscribed by the customer.

    /**
     * Constructs a new Customer object with the specified name, email,
     * magazines, and supplements.
     *
     * @param name The name of the customer.
     * @param email The email address of the customer.
     * @param magazines The list of magazines subscribed by the customer.
     * @param supplements The list of supplements subscribed by the customer.
     */
    public Customer(String name, String email, List<Magazine> magazines, List<Supplement> supplements) {
        this.name = name;
        this.email = email;
        this.magazines = magazines;
        this.supplements = supplements;
    }

    /**
     * Constructs a new Customer object.
     */
    public Customer() {
    }

    /**
     * Returns the name of the customer.
     *
     * @return The name of the customer.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the customer.
     *
     * @param name The name of the customer.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the email address of the customer.
     *
     * @return The email address of the customer.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email address of the customer.
     *
     * @param email The email address of the customer.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Returns the list of magazines subscribed by the customer.
     *
     * @return The list of magazines subscribed by the customer.
     */
    public List<Magazine> getMagazines() {
        return magazines;
    }

    /**
     * Sets the list of magazines subscribed by the customer.
     *
     * @param magazines The list of magazines subscribed by the customer.
     */
    public void setMagazines(List<Magazine> magazines) {
        this.magazines = magazines;
    }

    /**
     * Returns the list of supplements subscribed by the customer.
     *
     * @return The list of supplements subscribed by the customer.
     */
    public List<Supplement> getSupplements() {
        return supplements;
    }

    /**
     * Sets the list of supplements subscribed by the customer.
     *
     * @param supplements The list of supplements subscribed by the customer.
     */
    public void setSupplements(List<Supplement> supplements) {
        this.supplements = supplements;
    }

    /**
     * Calculates the total cost of all magazines subscribed by the customer.
     *
     * @return The total cost of all magazines.
     */
    public float getTotalMagazineCost() {
        float totalMagazineCost = 0;
        if (magazines != null) {
            for (Magazine mag : magazines) {
                totalMagazineCost += mag.getTotalMagazineCost();
            }
        }
        return totalMagazineCost;
    }

    /**
     * Calculates the total cost of all supplements subscribed by the customer.
     *
     * @return The total cost of all supplements.
     */
    public float getTotalSupplementCost() {
        float totalSupplementCost = 0;
        if (supplements != null) {
            for (Supplement supp : supplements) {
                totalSupplementCost += supp.getSupplementCost();
            }
        }
        return totalSupplementCost;
    }

    /**
     * Calculates the total cost of all subscriptions (magazines and
     * supplements) by the customer.
     *
     * @return The total cost of all subscriptions.
     */
    public float getTotalCost() {
        return getTotalMagazineCost() + getTotalSupplementCost();
    }

    /**
     * Prints a weekly notification for the customer detailing subscribed
     * magazines, associated supplements, and total cost.
     */
    public void weeklyNotification() {
        float totalCost = 0;
        System.out.println();
        System.out.println("Associate Customer Details:");
        System.out.println("Customer Name: " + this.getName());
        System.out.println("Customer Email: " + this.getEmail());

        // List the magazine and its supplements
        if (magazines != null && !magazines.isEmpty()) {
            System.out.println("Magazine and its associated supplements:");
            for (Magazine mag : magazines) {
                System.out.println("Magazine Name: " + mag.getMagazineName());
                System.out.println("Magazine Cost: " + mag.getMagazineCost());
                System.out.println("Magazine Total Cost: " + mag.getTotalMagazineCost());

                List<Supplement> magazineSupplements = mag.getMagazineSupplement();
                if (magazineSupplements != null && !magazineSupplements.isEmpty()) {
                    System.out.println("Supplements:");
                    for (Supplement supplement : magazineSupplements) {
                        System.out.println("\tSupplement Name: " + supplement.getSupplementName());
                        System.out.println("\tSupplement Cost: " + supplement.getSupplementCost());
                    }
                } else {
                    System.out.println("No supplements associated with this magazine.");
                }
                System.out.println("-----------------------------------------");

                totalCost += mag.getTotalMagazineCost();
            }
        } else {
            System.out.println("No magazines associated with this customer.");
        }

        // List standalone supplements
        if (supplements != null && !supplements.isEmpty()) {
            System.out.println("Standalone Supplements:");
            for (Supplement supp : supplements) {
                System.out.println("Supplement Name: " + supp.getSupplementName());
                System.out.println("Supplement Cost: " + supp.getSupplementCost());

                totalCost += supp.getSupplementCost();
            }
        } else {
            System.out.println("No standalone supplements associated with this customer.");
        }

        // Display total cost
        System.out.println("Total Cost: " + totalCost);
    }

    /**
     * Displays the details of the customer, including subscribed magazines and
     * supplements.
     */
    public void display() {
        System.out.println("-----------------------------------------");
        System.out.println("-----------------------------------------");
        System.out.println("-----------------------------------------");
        System.out.println("Associate Customer details");
        System.out.println("Customer Name: " + this.name);
        System.out.println("Customer Email: " + this.email);
        System.out.println();

        if (magazines != null && !magazines.isEmpty()) {
            System.out.println("-----------------------------------------");
            System.out.println("Magazine and it's associated supplements");
            System.out.println("-----------------------------------------");
            for (Magazine mag : magazines) {
                mag.display();  // Call the display method in Magazine class
            }
        } else {
            System.out.println("No magazines associated with this customer.");
        }
        System.out.println("---------------------------------");
        // Display supplement details
        if (supplements != null && !supplements.isEmpty()) {
            System.out.println("---Supplement Details---:");
            for (Supplement supp : supplements) {
                supp.display();  // Call the display method in Supplement class
            }
        } else {
            System.out.println("No supplements associated with this customer.");
        }

    }

    /**
     * Adds a standalone supplement to the customer's subscription.
     *
     * @param newSupplement The new supplement to add.
     */
    public void addStandaloneSupplement(Supplement newSupplement) {
        if (supplements == null) {
            supplements = new ArrayList<>();
        }
        supplements.add(newSupplement);
    }

    /**
     * Adds a magazine to the customer's subscription.
     *
     * @param newMagazine The new magazine to add.
     */
    public void addMagazine(Magazine newMagazine) {
        if (magazines == null) {
            magazines = new ArrayList<>();
        }
        magazines.add(newMagazine);
    }

    /**
     * Adds a supplement to the customer's subscription.
     *
     * @param newSupplement The new supplement to add.
     */
    public void addSupplement(Supplement newSupplement) {
        if (supplements == null) {
            supplements = new ArrayList<>();
        }
        supplements.add(newSupplement);
    }

    /**
     * Removes a magazine from the customer's subscription.
     *
     * @param magazine The magazine to remove.
     */
    public void removeMagazine(Magazine magazine) {
        if (magazines != null && magazines.contains(magazine)) {
            magazines.remove(magazine);
            System.out.println("Magazine \"" + magazine.getMagazineName() + "\" removed successfully from customer " + this.name);
        } else {
            System.out.println("The magazine is not associated with this customer.");
        }
    }

    /**
     * Removes a supplement from the customer's subscription.
     *
     * @param supplement The supplement to remove.
     */
    public void removeSupplement(Supplement supplement) {
        if (supplements != null && supplements.contains(supplement)) {
            supplements.remove(supplement);
            System.out.println("Supplement \"" + supplement.getSupplementName() + "\" removed successfully from customer " + this.name);
        } else {
            System.out.println("The supplement is not associated with this customer.");
        }
    }

    /**
     * Displays the customer's details in a graphical user interface.
     *
     * @return A Node representing the customer's details.
     */
    public Node displayGUI() {
        VBox vbox = new VBox(5); // VBox with a spacing of 5
        vbox.getChildren().add(new Label("Customer Name: " + this.name));
        vbox.getChildren().add(new Label("Customer Email: " + this.email));

        if (magazines != null && !magazines.isEmpty()) {
            vbox.getChildren().add(new Label("Magazines and Associated Supplements:"));
            for (Magazine mag : magazines) {
                vbox.getChildren().add(mag.displayGUI()); // Now directly adding the Node
            }
        } else {
            vbox.getChildren().add(new Label("No magazines associated with this customer."));
        }

        if (supplements != null && !supplements.isEmpty()) {
            vbox.getChildren().add(new Label("Standalone Supplements:"));
            for (Supplement supp : supplements) {
                vbox.getChildren().add(supp.displayGUI()); // Now directly adding the Node
            }
        } else {
            vbox.getChildren().add(new Label("No standalone supplements associated with this customer."));
        }

        vbox.getChildren().add(new Label("Total Cost: $" + String.format("%.2f", getTotalCost())));
        return vbox; // Return the VBox as a Node
    }

    /**
     * Returns the name of the customer as a string.
     *
     * @return The name of the customer.
     */
    @Override
    public String toString() {
        return this.getName(); // Assuming you have a getName() method that returns the customer's name
    }

}
