package com.mycompany.assignment2v2;

/**
 * Title: Assignment2 Author: Yin Zhanpeng Date: 29/3/2024 File Name:
 * Assignment2
 *
 * <p>
 * Program Description:</p>
 * <p>
 * This program simulates the weekly and monthly notifications for customers
 * subscribed to magazines and supplements. It allows user interactions for
 * managing subscriptions and customer information.</p>
 *
 * <p>
 * Assumptions/Conditions:</p>
 * <ol>
 * <li>The customers have a list of Supplements and Magazines.</li>
 * <li>Supplements can be individual or included within magazines.</li>
 * <li>Magazines contain their own list of Supplements.</li>
 * <li>The program allows the user to add supplements to both magazines and
 * customers.</li>
 * <li>Paying customers have a list of associate customers.</li>
 * <li>Both the paying and associate customers have their own
 * subscriptions.</li>
 * <li>The program only simulates weekly and monthly notifications.</li>
 * <li>Associate customers of a paying customer can be removed.</li>
 * <li>Removing a paying customer also removes its associated customers.</li>
 * <li>Customers contain magazines, not the other way around.</li>
 * <li>There should be at least one paying customer.</li>
 * <li>Textual data inputs for customer names, addresses, email addresses,
 * supplement names, etc., are handled.</li>
 * <li>Payment methods are represented as strings or simple identifiers.</li>
 * <li>The GUI is designed for desktop use and is not optimized for mobile
 * devices.</li>
 * <li>Billing history is displayed in a simple tabular format.</li>
 * <li>Customer address details are limited to basic information.</li>
 * <li>The program handles a reasonable number of entities without significant
 * performance degradation.</li>
 * <li>Basic error handling is implemented for scenarios such as invalid input
 * formats and file I/O errors.</li>
 * <li>The GUI layout is implemented using JavaFX controls and layouts.</li>
 * <li>The program is developed and tested on the Java SE 8 platform using
 * NetBeans IDE.</li>
 * <li>Data persistence is achieved through serialization.</li>
 * </ol>
 */
import java.util.Scanner;
import java.util.List;

/**
 * The CreateCustomer class provides methods to create different types of
 * customers. It allows the user to interactively create paying customers,
 * associate customers, and display lists of customers.
 */
public class CreateCustomer {

    /**
     * Runs the customer creation process.
     *
     * @param database The database instance to interact with.
     */
    public static void run(Database database) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Choose an action:");
            System.out.println("1. Create Paying Customer");
            System.out.println("2. Create Associate Customer");
            System.out.println("3. Display Lists");
            System.out.println("4. Quit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createPayingCustomer(database, scanner);
                    break;
                case 2:
                    createAssociateCustomer(database, scanner);
                    break;
                case 3:
                    displayLists(database);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    /**
     * Creates a new paying customer based on user input and adds it to the
     * database.
     *
     * @param database The database instance to interact with.
     * @param scanner The Scanner object to read user input.
     */
    private static void createPayingCustomer(Database database, Scanner scanner) {
        PayingCustomer payingCustomer = new PayingCustomer();

        System.out.print("Enter customer name: ");
        payingCustomer.setName(scanner.nextLine());

        System.out.print("Enter customer email: ");
        payingCustomer.setEmail(scanner.nextLine());

        // Set supplements to null for now
        payingCustomer.setSupplements(null);

        System.out.println("Choose payment method:");
        System.out.println("1. Credit Card");
        System.out.println("2. Bank Card");
        System.out.print("Enter your choice: ");
        int paymentChoice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (paymentChoice) {
            case 1:
                payingCustomer.setSelectedPaymentMethod(PayingCustomer.PaymentMethod.CREDIT_CARD);
                break;
            case 2:
                payingCustomer.setSelectedPaymentMethod(PayingCustomer.PaymentMethod.BANK_CARD);
                break;
            default:
                System.out.println("Invalid choice. Defaulting to Credit Card.");
                payingCustomer.setSelectedPaymentMethod(PayingCustomer.PaymentMethod.CREDIT_CARD);
        }

        System.out.print("Enter bank: ");
        payingCustomer.setBank(scanner.nextLine());

        // Add paying customer to the database
        database.addPayingCustomer(payingCustomer);
        System.out.println("Paying customer created successfully.");
    }

    /**
     * Creates a new associate customer based on user input and adds it to the
     * database.
     *
     * @param database The database instance to interact with.
     * @param scanner The Scanner object to read user input.
     */
    private static void createAssociateCustomer(Database database, Scanner scanner) {
        Customer associateCustomer = new Customer();

        System.out.print("Enter customer name: ");
        associateCustomer.setName(scanner.nextLine());

        System.out.print("Enter customer email: ");
        associateCustomer.setEmail(scanner.nextLine());

        // Set supplements to null for now
        associateCustomer.setSupplements(null);

        // Add associate customer to the database
        database.addAssociateCustomer(associateCustomer);
        System.out.println("Associate customer created successfully.");
    }

    /**
     * Displays lists of paying customers and associate customers.
     *
     * @param database The database instance to interact with.
     */
    private static void displayLists(Database database) {
        System.out.println("List of Paying Customers:");
        for (PayingCustomer payingCustomer : database.getPayingCustomers()) {
            System.out.println(payingCustomer.getName());
            System.out.println("Associated Customers:");
            List<Customer> associatedCustomers = payingCustomer.getAssociateCustomers();
            if (associatedCustomers != null && !associatedCustomers.isEmpty()) {
                for (Customer associate : associatedCustomers) {
                    System.out.println("- " + associate.getName());
                }
            } else {
                System.out.println("No associated customers.");
            }
            System.out.println();
        }

        System.out.println("List of Associate Customers:");
        List<Customer> associateCustomers = database.getAssociateCustomers();
        if (associateCustomers != null && !associateCustomers.isEmpty()) {
            for (Customer associateCustomer : associateCustomers) {
                System.out.println(associateCustomer.getName());
                System.out.println();
            }
        } else {
            System.out.println("No associate customers found.");
        }
    }

}
