package com.mycompany.assignment2v2;

/**
 * Title: Assignment2 Author: Yin Zhanpeng Date: 29/3/2024 File Name:
 * Assignment2
 *
 * <p>
 * Program Description:</p>
 * <p>
 * This program simulates the weekly and monthly notifications for customers
 * subscribed to magazines and supplements. It allows user interactions for
 * managing subscriptions and customer information.</p>
 *
 * <p>
 * Assumptions/Conditions:</p>
 * <ol>
 * <li>The customers have a list of Supplements and Magazines.</li>
 * <li>Supplements can be individual or included within magazines.</li>
 * <li>Magazines contain their own list of Supplements.</li>
 * <li>The program allows the user to add supplements to both magazines and
 * customers.</li>
 * <li>Paying customers have a list of associate customers.</li>
 * <li>Both the paying and associate customers have their own
 * subscriptions.</li>
 * <li>The program only simulates weekly and monthly notifications.</li>
 * <li>Associate customers of a paying customer can be removed.</li>
 * <li>Removing a paying customer also removes its associated customers.</li>
 * <li>Customers contain magazines, not the other way around.</li>
 * <li>There should be at least one paying customer.</li>
 * <li>Textual data inputs for customer names, addresses, email addresses,
 * supplement names, etc., are handled.</li>
 * <li>Payment methods are represented as strings or simple identifiers.</li>
 * <li>The GUI is designed for desktop use and is not optimized for mobile
 * devices.</li>
 * <li>Billing history is displayed in a simple tabular format.</li>
 * <li>Customer address details are limited to basic information.</li>
 * <li>The program handles a reasonable number of entities without significant
 * performance degradation.</li>
 * <li>Basic error handling is implemented for scenarios such as invalid input
 * formats and file I/O errors.</li>
 * <li>The GUI layout is implemented using JavaFX controls and layouts.</li>
 * <li>The program is developed and tested on the Java SE 8 platform using
 * NetBeans IDE.</li>
 * <li>Data persistence is achieved through serialization.</li>
 * </ol>
 */
import java.util.List;
import java.util.Scanner;

/**
 * The CreateSupplement class provides methods to interactively create new
 * supplements and add them to the database.
 */
public class CreateSupplement {

    /**
     * Runs the process of creating a new supplement.
     *
     * @param database The database instance to interact with.
     */
    public static void run(Database database) {
        Scanner scanner = new Scanner(System.in);
        List<Supplement> supplements = database.getSupplements();

        displayExistingSupplements(supplements);
        if (promptToAddNewSupplement(scanner)) {
            String supplementName = promptForSupplementName(scanner);
            float supplementCost = promptForSupplementCost(scanner);
            addNewSupplement(database, supplementName, supplementCost);
        } else {
            System.out.println("No new supplement added.");
        }
    }

    /**
     * Displays a list of existing supplements.
     *
     * @param supplements The list of existing supplements to display.
     */
    private static void displayExistingSupplements(List<Supplement> supplements) {
        System.out.println("Existing Supplements:");
        for (Supplement supplement : supplements) {
            supplement.display();
        }
    }

    /**
     * Prompts the user to indicate whether they want to add a new supplement.
     *
     * @param scanner The Scanner object to read user input.
     * @return True if the user wants to add a new supplement, false otherwise.
     */
    private static boolean promptToAddNewSupplement(Scanner scanner) {
        System.out.print("Do you want to add a new supplement? (yes/no): ");
        String choice = scanner.nextLine();
        return choice.equalsIgnoreCase("yes");
    }

    /**
     * Prompts the user to enter the name of the new supplement.
     *
     * @param scanner The Scanner object to read user input.
     * @return The name of the new supplement entered by the user.
     */
    private static String promptForSupplementName(Scanner scanner) {
        System.out.print("Enter the supplement name: ");
        return scanner.nextLine();
    }

    /**
     * Prompts the user to enter the cost of the new supplement.
     *
     * @param scanner The Scanner object to read user input.
     * @return The cost of the new supplement entered by the user.
     */
    private static float promptForSupplementCost(Scanner scanner) {
        System.out.print("Enter the supplement cost: ");
        return scanner.nextFloat();
    }

    /**
     * Adds a new supplement to the database.
     *
     * @param database The database instance to add the new supplement to.
     * @param supplementName The name of the new supplement.
     * @param supplementCost The cost of the new supplement.
     */
    private static void addNewSupplement(Database database, String supplementName, float supplementCost) {
        Supplement newSupplement = new Supplement(supplementName, supplementCost);
        database.addSupplement(newSupplement);
        System.out.println("New supplement added successfully.");
    }
}
