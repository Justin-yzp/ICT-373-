package com.mycompany.assignment2v2;

/**
 * Title: Assignment2 Author: Yin Zhanpeng Date: 29/3/2024 File Name:
 * Assignment2
 *
 * <p>
 * Program Description:</p>
 * <p>
 * This program simulates the weekly and monthly notifications for customers
 * subscribed to magazines and supplements. It allows user interactions for
 * managing subscriptions and customer information.</p>
 *
 * <p>
 * Assumptions/Conditions:</p>
 * <ol>
 * <li>The customers have a list of Supplements and Magazines.</li>
 * <li>Supplements can be individual or included within magazines.</li>
 * <li>Magazines contain their own list of Supplements.</li>
 * <li>The program allows the user to add supplements to both magazines and
 * customers.</li>
 * <li>Paying customers have a list of associate customers.</li>
 * <li>Both the paying and associate customers have their own
 * subscriptions.</li>
 * <li>The program only simulates weekly and monthly notifications.</li>
 * <li>Associate customers of a paying customer can be removed.</li>
 * <li>Removing a paying customer also removes its associated customers.</li>
 * <li>Customers contain magazines, not the other way around.</li>
 * <li>There should be at least one paying customer.</li>
 * <li>Textual data inputs for customer names, addresses, email addresses,
 * supplement names, etc., are handled.</li>
 * <li>Payment methods are represented as strings or simple identifiers.</li>
 * <li>The GUI is designed for desktop use and is not optimized for mobile
 * devices.</li>
 * <li>Billing history is displayed in a simple tabular format.</li>
 * <li>Customer address details are limited to basic information.</li>
 * <li>The program handles a reasonable number of entities without significant
 * performance degradation.</li>
 * <li>Basic error handling is implemented for scenarios such as invalid input
 * formats and file I/O errors.</li>
 * <li>The GUI layout is implemented using JavaFX controls and layouts.</li>
 * <li>The program is developed and tested on the Java SE 8 platform using
 * NetBeans IDE.</li>
 * <li>Data persistence is achieved through serialization.</li>
 * </ol>
 */
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.VBox;

/**
 * The Magazine class represents a magazine entity with its details and
 * associated supplements.
 */
public class Magazine implements Serializable {

    private String magazineName;
    private float magazineCost;
    private List<Supplement> magazineSupplement;

    /**
     * Constructs a Magazine object with the specified name, cost, and list of
     * supplements.
     *
     * @param magazineName The name of the magazine.
     * @param magazineCost The cost of the magazine.
     * @param magazineSupplement The list of supplements associated with the
     * magazine.
     */
    public Magazine(String magazineName, float magazineCost, List<Supplement> magazineSupplement) {
        this.magazineName = magazineName;
        this.magazineCost = magazineCost;
        this.magazineSupplement = magazineSupplement;
    }

    /**
     * Retrieves the name of the magazine.
     *
     * @return The name of the magazine.
     */
    public String getMagazineName() {
        return magazineName;
    }

    /**
     * Sets the name of the magazine.
     *
     * @param magazineName The name of the magazine.
     */
    public void setMagazineName(String magazineName) {
        this.magazineName = magazineName;
    }

    /**
     * Retrieves the cost of the magazine.
     *
     * @return The cost of the magazine.
     */
    public float getMagazineCost() {
        return magazineCost;
    }

    /**
     * Sets the cost of the magazine.
     *
     * @param magazineCost The cost of the magazine.
     */
    public void setMagazineCost(float magazineCost) {
        this.magazineCost = magazineCost;
    }

    /**
     * Retrieves the list of supplements associated with the magazine.
     *
     * @return The list of supplements associated with the magazine.
     */
    public List<Supplement> getMagazineSupplement() {
        return magazineSupplement;
    }

    /**
     * Sets the list of supplements associated with the magazine.
     *
     * @param magazineSupplement The list of supplements associated with the
     * magazine.
     */
    public void setMagazineSupplement(List<Supplement> magazineSupplement) {
        this.magazineSupplement = magazineSupplement;
    }

    /**
     * Calculates the total cost of the magazine including its supplements.
     *
     * @return The total cost of the magazine.
     */
    public float getTotalMagazineCost() {
        float totalCost = magazineCost;
        if (magazineSupplement != null) {
            for (Supplement supplement : magazineSupplement) {
                totalCost += supplement.getSupplementCost();
            }
        }

        return totalCost;
    }

    /**
     * Returns the name of the magazine.
     *
     * @return The name of the magazine.
     */
    @Override
    public String toString() {
        return magazineName; // This will be used by ListView to display the magazine's name.
    }

    /**
     * Displays the details of the magazine including its name, cost, and
     * associated supplements.
     */
    public void display() {
        System.out.println();
        System.out.println("--------------------");
        System.out.println("Magazine Details");
        System.out.println("Magazine Name: " + magazineName);
        System.out.println("Magazine Cost: " + magazineCost);
        System.out.println();

        if (magazineSupplement != null) {
            System.out.println("Magazine Supplements Details:");
            for (Supplement supplement : magazineSupplement) {
                supplement.display();
            }
        } else {
            System.out.println("No supplements available for this magazine.");
        }
    }

    /**
     * Adds a supplement to the magazine.
     *
     * @param supplement The supplement to be added.
     */
    public void addSupplement(Supplement supplement) {
        if (magazineSupplement == null) {
            magazineSupplement = new ArrayList<>();
        }
        magazineSupplement.add(supplement);
    }

    /**
     * Removes a supplement from the magazine.
     *
     * @param supplement The supplement to be removed.
     */
    public void removeSupplement(Supplement supplement) {
        if (magazineSupplement != null) {
            magazineSupplement.remove(supplement);
        }
    }

    /**
     * Displays the graphical user interface representation of the magazine.
     *
     * @return A Node representing the GUI of the magazine.
     */
    public Node displayGUI() {
        VBox vbox = new VBox(5); // VBox with a spacing of 5
        vbox.getChildren().add(new Separator());
        vbox.getChildren().add(new Label("Magazine Details"));
        vbox.getChildren().add(new Label("Magazine Name: " + magazineName));
        vbox.getChildren().add(new Label("Magazine Cost: " + String.format("%.2f", magazineCost)));

        if (magazineSupplement != null && !magazineSupplement.isEmpty()) {
            vbox.getChildren().add(new Label("Magazine Supplements Details:"));
            for (Supplement supplement : magazineSupplement) {
                vbox.getChildren().add(supplement.displayGUI()); // Assuming displayGUI() returns a Node
            }
        } else {
            vbox.getChildren().add(new Label("No supplements available for this magazine."));
        }

        return vbox; // Return the VBox as a Node
    }

}
