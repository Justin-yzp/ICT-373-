package com.mycompany.assignment2v2;

/**
 * Title: Assignment2 Author: Yin Zhanpeng Date: 29/3/2024 File Name:
 * Assignment2
 *
 * <p>
 * Program Description:</p>
 * <p>
 * This program simulates the weekly and monthly notifications for customers
 * subscribed to magazines and supplements. It allows user interactions for
 * managing subscriptions and customer information.</p>
 *
 * <p>
 * Assumptions/Conditions:</p>
 * <ol>
 * <li>The customers have a list of Supplements and Magazines.</li>
 * <li>Supplements can be individual or included within magazines.</li>
 * <li>Magazines contain their own list of Supplements.</li>
 * <li>The program allows the user to add supplements to both magazines and
 * customers.</li>
 * <li>Paying customers have a list of associate customers.</li>
 * <li>Both the paying and associate customers have their own
 * subscriptions.</li>
 * <li>The program only simulates weekly and monthly notifications.</li>
 * <li>Associate customers of a paying customer can be removed.</li>
 * <li>Removing a paying customer also removes its associated customers.</li>
 * <li>Customers contain magazines, not the other way around.</li>
 * <li>There should be at least one paying customer.</li>
 * <li>Textual data inputs for customer names, addresses, email addresses,
 * supplement names, etc., are handled.</li>
 * <li>Payment methods are represented as strings or simple identifiers.</li>
 * <li>The GUI is designed for desktop use and is not optimized for mobile
 * devices.</li>
 * <li>Billing history is displayed in a simple tabular format.</li>
 * <li>Customer address details are limited to basic information.</li>
 * <li>The program handles a reasonable number of entities without significant
 * performance degradation.</li>
 * <li>Basic error handling is implemented for scenarios such as invalid input
 * formats and file I/O errors.</li>
 * <li>The GUI layout is implemented using JavaFX controls and layouts.</li>
 * <li>The program is developed and tested on the Java SE 8 platform using
 * NetBeans IDE.</li>
 * <li>Data persistence is achieved through serialization.</li>
 * </ol>
 */
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.VBox;

/**
 * The PayingCustomer class represents a paying customer entity, extending the
 * Customer class, with additional attributes such as selected payment method,
 * bank, and associated customers.
 */
public class PayingCustomer extends Customer implements Serializable {
//private static final long serialVersionUID = -1763755671558395339L;

    /**
     * Enumeration representing different payment methods.
     */
    public enum PaymentMethod {

        CREDIT_CARD,
        BANK_CARD
    }
    private PaymentMethod selectedPaymentMethod;
    private String bank;
    private List<Customer> associateCustomers;

    /**
     * Constructs a PayingCustomer object with the specified attributes.
     *
     * @param selectedPaymentMethod The selected payment method.
     * @param bank The bank associated with the paying customer.
     * @param associateCustomer The list of associated customers.
     * @param name The name of the paying customer.
     * @param email The email of the paying customer.
     * @param magazines The list of magazines associated with the paying
     * customer.
     * @param supplements The list of supplements associated with the paying
     * customer.
     */
    public PayingCustomer(PaymentMethod selectedPaymentMethod, String bank, List<Customer> associateCustomer, String name, String email, List<Magazine> magazines, List<Supplement> supplements) {
        super(name, email, magazines, supplements);
        this.selectedPaymentMethod = selectedPaymentMethod;
        this.bank = bank;
        this.associateCustomers = associateCustomer;
    }

    /**
     * Constructs a PayingCustomer object with the specified attributes.
     *
     * @param selectedPaymentMethod The selected payment method.
     * @param bank The bank associated with the paying customer.
     * @param associateCustomer The list of associated customers.
     */
    public PayingCustomer(PaymentMethod selectedPaymentMethod, String bank, List<Customer> associateCustomer) {
        this.selectedPaymentMethod = selectedPaymentMethod;
        this.bank = bank;
        this.associateCustomers = associateCustomer;
    }

    /**
     * Constructs a default PayingCustomer object.
     */
    public PayingCustomer() {
        super();
        associateCustomers = new ArrayList<>();
    }

    /**
     * Retrieves the selected payment method of the paying customer.
     *
     * @return The selected payment method.
     */
    public PaymentMethod getSelectedPaymentMethod() {
        return selectedPaymentMethod;
    }

    /**
     * Sets the selected payment method of the paying customer.
     *
     * @param selectedPaymentMethod The selected payment method.
     */
    public void setSelectedPaymentMethod(PaymentMethod selectedPaymentMethod) {
        this.selectedPaymentMethod = selectedPaymentMethod;
    }

    /**
     * Retrieves the bank associated with the paying customer.
     *
     * @return The bank associated with the paying customer.
     */
    public String getBank() {
        return bank;
    }

    /**
     * Sets the bank associated with the paying customer.
     *
     * @param bank The bank associated with the paying customer.
     */
    public void setBank(String bank) {
        this.bank = bank;
    }

    /**
     * Retrieves the list of associated customers.
     *
     * @return The list of associated customers.
     */
    public List<Customer> getAssociateCustomers() {
        return associateCustomers;
    }

    /**
     * Sets the list of associated customers.
     *
     * @param associateCustomer The list of associated customers.
     */
    public void setAssociateCustomer(List<Customer> associateCustomer) {
        this.associateCustomers = associateCustomer;
    }

    /**
     * Adds an associate customer to the paying customer's list of associated
     * customers.
     *
     * @param customer The associate customer to be added.
     */
    public void addAssociateCustomer(Customer customer) {
        if (this.associateCustomers == null) {
            this.associateCustomers = new ArrayList<>();
        }
        this.associateCustomers.add(customer);
    }

    /**
     * Generates and displays the weekly notification for the paying customer.
     */
    @Override
    public void weeklyNotification() {
        float totalCost = 0;

        // Display customer details
        System.out.println();
        System.out.println("Paying Customer Details:");
        System.out.println("Customer Name: " + this.getName());
        System.out.println("Customer Email: " + this.getEmail());
        System.out.println("Selected Payment Method: " + this.selectedPaymentMethod);
        System.out.println("Bank: " + this.bank);
        System.out.println();

        // List the magazine and its supplements
        if (this.getMagazines() != null && !this.getMagazines().isEmpty()) {
            System.out.println("Magazines and their associated supplements:");
            for (Magazine mag : this.getMagazines()) {
                System.out.println("Magazine Name: " + mag.getMagazineName());
                System.out.println("Magazine Cost: " + mag.getMagazineCost());
                System.out.println("Magazine Total Cost: " + mag.getTotalMagazineCost());

                List<Supplement> magazineSupplements = mag.getMagazineSupplement();
                if (magazineSupplements != null && !magazineSupplements.isEmpty()) {
                    System.out.println("Supplements:");
                    for (Supplement supplement : magazineSupplements) {
                        System.out.println("\tSupplement Name: " + supplement.getSupplementName());
                        System.out.println("\tSupplement Cost: " + supplement.getSupplementCost());
                    }
                } else {
                    System.out.println("No supplements associated with this magazine.");
                }
                System.out.println("-----------------------------------------");

                totalCost += mag.getTotalMagazineCost();
            }
        } else {
            System.out.println("No magazines associated with this customer.");
        }

        // List standalone supplements
        if (this.getSupplements() != null && !this.getSupplements().isEmpty()) {
            System.out.println("Standalone Supplements:");
            for (Supplement supp : this.getSupplements()) {
                System.out.println("Supplement Name: " + supp.getSupplementName());
                System.out.println("Supplement Cost: " + supp.getSupplementCost());

                totalCost += supp.getSupplementCost();
            }
        } else {
            System.out.println("No standalone supplements associated with this customer.");
        }

        // Display total cost
        System.out.println("Total Cost: " + totalCost);
    }

    private float calculateAndDisplayCustomerCost(Customer customer) {
        float customerTotalCost = 0;

        // Display customer name and email
        System.out.println("Customer Name: " + customer.getName());
        System.out.println("Customer Email: " + customer.getEmail());

        // Display magazines and their associated costs
        if (customer.getMagazines() != null && !customer.getMagazines().isEmpty()) {
            System.out.println("Magazines and their associated costs:");
            for (Magazine mag : customer.getMagazines()) {
                float magazineCost = mag.getMagazineCost();
                System.out.println("Magazine Name: " + mag.getMagazineName() + ", Cost: " + magazineCost);
                customerTotalCost += magazineCost;

                // Display supplements for this magazine
                List<Supplement> magazineSupplements = mag.getMagazineSupplement();
                if (magazineSupplements != null && !magazineSupplements.isEmpty()) {
                    System.out.println("Supplements in this Magazine:");
                    for (Supplement supplement : magazineSupplements) {
                        float supplementCost = supplement.getSupplementCost();
                        System.out.println("\tSupplement name: " + supplement.getSupplementName() + ", Cost: " + supplementCost);
                        customerTotalCost += supplementCost;
                    }
                }
            }
        } else {
            System.out.println("No magazines associated with this customer.");
        }

        // Display standalone supplements and their costs
        if (customer.getSupplements() != null && !customer.getSupplements().isEmpty()) {
            System.out.println("Standalone Supplements and their costs:");
            for (Supplement supp : customer.getSupplements()) {
                float supplementCost = supp.getSupplementCost();
                System.out.println("Supplement name: " + supp.getSupplementName() + ", Cost: " + supplementCost);
                customerTotalCost += supplementCost;
            }
        } else {
            System.out.println("No standalone supplements associated with this customer.");
        }

        // Display total cost for the customer
        System.out.println("Total Cost for the Customer: " + customerTotalCost);
        System.out.println();

        return customerTotalCost;
    }

    /**
     * Generates and displays the monthly notification for the paying customer.
     */
    public void monthlyNotification() {
        // Display customer details
        System.out.println("Monthly Notification for Paying Customer:");
        System.out.println("Customer Name: " + this.getName());
        System.out.println("Customer Email: " + this.getEmail());
        System.out.println("Selected Payment Method: " + this.selectedPaymentMethod);
        System.out.println("Bank: " + this.bank);
        System.out.println();

        // Calculate and display total cost for the paying customer
        float totalCost = calculateAndDisplayCustomerCost(this);

        // Display associate customers and their associated magazines and supplements
        if (this.associateCustomers != null && !this.associateCustomers.isEmpty()) {
            for (Customer associate : this.associateCustomers) {
                // Calculate and display total cost for the associate customer
                totalCost += calculateAndDisplayCustomerCost(associate);
            }
        } else {
            System.out.println("No associate customers.");
        }

        // Display total cost for the paying customer and their associate customers
        System.out.println("Total Cost for the Month (Including Associate Customers): " + totalCost);
    }

    /**
     * Generates a comprehensive billing information for the paying customer and
     * their associated customers.
     *
     * @return The BillingInfo object containing the billing details.
     */
    public BillingInfo generateComprehensiveBillingInfo() {
        BillingInfo billingInfo = new BillingInfo(this.getName(), this.getEmail());

        // Adding billing details for the paying customer
        billingInfo.addDetail("Paying Customer Details:", 0); // 0 cost as a placeholder for a header
        billingInfo.addDetail("Name: " + this.getName(), 0);
        billingInfo.addDetail("Email: " + this.getEmail(), 0);
        billingInfo.addDetail("Payment Method: " + this.selectedPaymentMethod, 0);
        billingInfo.addDetail("Bank: " + this.bank, 0);
        billingInfo.addDetail("--------", 0); // Visual separator

        // Magazines and their supplements
        for (Magazine magazine : this.getMagazines()) {
            billingInfo.addDetail("Magazine: " + magazine.getMagazineName(), magazine.getMagazineCost());
            for (Supplement supplement : magazine.getMagazineSupplement()) {
                billingInfo.addDetail("  Supplement: " + supplement.getSupplementName(), supplement.getSupplementCost());
            }
        }

        // Standalone supplements
        for (Supplement supplement : this.getSupplements()) {
            billingInfo.addDetail("Supplement: " + supplement.getSupplementName(), supplement.getSupplementCost());
        }

        // Associated Customers
        if (!this.getAssociateCustomers().isEmpty()) {
            billingInfo.addDetail("Associated Customers Details:", 0); // 0 cost as a placeholder for a header
            for (Customer associate : this.getAssociateCustomers()) {
                billingInfo.addDetail("Associate Name: " + associate.getName(), 0);
                billingInfo.addDetail("Associate Email: " + associate.getEmail(), 0);
                for (Magazine magazine : associate.getMagazines()) {
                    billingInfo.addDetail("  Magazine: " + magazine.getMagazineName(), magazine.getMagazineCost());
                    for (Supplement supplement : magazine.getMagazineSupplement()) {
                        billingInfo.addDetail("    Supplement: " + supplement.getSupplementName(), supplement.getSupplementCost());
                    }
                }
                for (Supplement supplement : associate.getSupplements()) {
                    billingInfo.addDetail("  Supplement: " + supplement.getSupplementName(), supplement.getSupplementCost());
                }
                billingInfo.addDetail("--------", 0); // Visual separator for each associate
            }
        }

        // Total Cost: This line aggregates all individual costs added above.
        //billingInfo.addDetail("Total Cost", billingInfo.getTotalCost());
        return billingInfo;
    }

    /**
     * Displays the details of the paying customer including associated
     * magazines, supplements, and customers.
     */
    @Override
    public void display() {
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println("Paying Customer Details:");
        System.out.println("Customer Name: " + this.getName());
        System.out.println("Customer Email: " + this.getEmail());
        System.out.println("Selected Payment Method: " + this.selectedPaymentMethod);
        System.out.println("Bank: " + this.bank);
        System.out.println();

        // Display associated magazines
        if (this.getMagazines() != null && !this.getMagazines().isEmpty()) {
            System.out.println("-----------------------------------------");
            System.out.println("Magazines and their associated supplements:");
            System.out.println("-----------------------------------------");
            for (Magazine mag : this.getMagazines()) {
                mag.display();
            }
        } else {
            System.out.println("No magazines associated with this customer.");
        }
        System.out.println("---------------------------------");

        // Display associated supplements
        if (this.getSupplements() != null && !this.getSupplements().isEmpty()) {
            System.out.println("---Supplement Details---:");
            for (Supplement supp : this.getSupplements()) {
                supp.display();
            }
        } else {
            System.out.println("No supplements associated with this customer.");
        }

        // Display associated customers
        if (this.associateCustomers != null && !this.associateCustomers.isEmpty()) {
            System.out.println();
            System.out.println("-----------------------------------------------");
            System.out.println("Associated Customers:");

            for (Customer customer : this.associateCustomers) {
                customer.display();
            }
        } else {
            System.out.println("No associated customers.");
        }
    }

    /**
     * Displays the graphical user interface representation of the paying
     * customer including associated magazines, supplements, and customers.
     *
     * @return A Node representing the GUI of the paying customer.
     */
    @Override
    public Node displayGUI() {
        VBox vbox = new VBox(5); // Create a VBox with a spacing of 5

        // Paying Customer Details Section
        vbox.getChildren().add(new Separator());
        vbox.getChildren().add(new Label("Paying Customer Details:"));
        vbox.getChildren().add(new Label("Customer Name: " + this.getName()));
        vbox.getChildren().add(new Label("Customer Email: " + this.getEmail()));
        vbox.getChildren().add(new Label("Selected Payment Method: " + this.selectedPaymentMethod));
        vbox.getChildren().add(new Label("Bank: " + this.bank));
        vbox.getChildren().add(new Separator());

        // Magazines and their associated supplements Section
        if (this.getMagazines() != null && !this.getMagazines().isEmpty()) {
            vbox.getChildren().add(new Label("Magazines and their associated supplements:"));
            for (Magazine mag : this.getMagazines()) {
                vbox.getChildren().add(mag.displayGUI()); // assuming Magazine class has a displayGUI() method that returns a Node
            }
        } else {
            vbox.getChildren().add(new Label("No magazines associated with this customer."));
        }
        vbox.getChildren().add(new Separator());

        // Supplement Details Section
        if (this.getSupplements() != null && !this.getSupplements().isEmpty()) {
            vbox.getChildren().add(new Label("Supplement Details:"));
            for (Supplement supp : this.getSupplements()) {
                vbox.getChildren().add(supp.displayGUI()); // assuming Supplement class has a displayGUI() method that returns a Node
            }
        } else {
            vbox.getChildren().add(new Label("No supplements associated with this customer."));
        }

        // Associated Customers Section
        if (this.associateCustomers != null && !this.associateCustomers.isEmpty()) {
            vbox.getChildren().add(new Separator());
            vbox.getChildren().add(new Label("Associated Customers:"));
            for (Customer customer : this.associateCustomers) {
                vbox.getChildren().add(customer.displayGUI()); // assuming Customer class has a displayGUI() method that returns a Node
            }
        } else {
            vbox.getChildren().add(new Label("No associated customers."));
        }

        return vbox; // Return the VBox as a Node
    }

    /**
     * Returns the name of the paying customer.
     *
     * @return The name of the paying customer.
     */
    @Override
    public String toString() {
        return this.getName(); // Assuming you have a getName() method that returns the customer's name
    }

}
