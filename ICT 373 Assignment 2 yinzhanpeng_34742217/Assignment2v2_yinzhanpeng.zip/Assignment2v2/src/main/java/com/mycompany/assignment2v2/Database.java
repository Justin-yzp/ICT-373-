package com.mycompany.assignment2v2;

/**
 * Title: Assignment2 Author: Yin Zhanpeng Date: 29/3/2024 File Name:
 * Assignment2
 *
 * <p>
 * Program Description:</p>
 * <p>
 * This program simulates the weekly and monthly notifications for customers
 * subscribed to magazines and supplements. It allows user interactions for
 * managing subscriptions and customer information.</p>
 *
 * <p>
 * Assumptions/Conditions:</p>
 * <ol>
 * <li>The customers have a list of Supplements and Magazines.</li>
 * <li>Supplements can be individual or included within magazines.</li>
 * <li>Magazines contain their own list of Supplements.</li>
 * <li>The program allows the user to add supplements to both magazines and
 * customers.</li>
 * <li>Paying customers have a list of associate customers.</li>
 * <li>Both the paying and associate customers have their own
 * subscriptions.</li>
 * <li>The program only simulates weekly and monthly notifications.</li>
 * <li>Associate customers of a paying customer can be removed.</li>
 * <li>Removing a paying customer also removes its associated customers.</li>
 * <li>Customers contain magazines, not the other way around.</li>
 * <li>There should be at least one paying customer.</li>
 * <li>Textual data inputs for customer names, addresses, email addresses,
 * supplement names, etc., are handled.</li>
 * <li>Payment methods are represented as strings or simple identifiers.</li>
 * <li>The GUI is designed for desktop use and is not optimized for mobile
 * devices.</li>
 * <li>Billing history is displayed in a simple tabular format.</li>
 * <li>Customer address details are limited to basic information.</li>
 * <li>The program handles a reasonable number of entities without significant
 * performance degradation.</li>
 * <li>Basic error handling is implemented for scenarios such as invalid input
 * formats and file I/O errors.</li>
 * <li>The GUI layout is implemented using JavaFX controls and layouts.</li>
 * <li>The program is developed and tested on the Java SE 8 platform using
 * NetBeans IDE.</li>
 * <li>Data persistence is achieved through serialization.</li>
 * </ol>
 */
import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;
import java.util.*;

/**
 * The Database class represents a database of supplements, magazines, paying
 * customers, and associate customers.
 */
public class Database implements Serializable {

    private List<Supplement> supplements; // The list of supplements in the database
    private List<Magazine> magazines; // The list of magazines in the database
    private List<PayingCustomer> payingCustomers; // The list of paying customers in the database
    private List<Customer> associateCustomers; // The list of associate customers in the database

    /**
     * Constructs a new Database object with empty lists.
     */
    public Database() {
        supplements = new ArrayList<>();
        magazines = new ArrayList<>();
        payingCustomers = new ArrayList<>();
        associateCustomers = new ArrayList<>(); // Initialize associateCustomers list
    }

    /**
     * Constructs a new Database object with the specified lists of supplements,
     * magazines, paying customers, and associate customers.
     *
     * @param supplements The list of supplements.
     * @param magazines The list of magazines.
     * @param payingCustomers The list of paying customers.
     * @param associateCustomers The list of associate customers.
     */
    public Database(List<Supplement> supplements, List<Magazine> magazines, List<PayingCustomer> payingCustomers, List<Customer> associateCustomers) {
        this.supplements = supplements;
        this.magazines = magazines;
        this.payingCustomers = payingCustomers;
        this.associateCustomers = associateCustomers;
    }

    /**
     * Populates the database with sample data.
     */
    public void populate() {
        Supplement supplement_1 = new Supplement("supplement_1 ", 1);
        Supplement supplement_2 = new Supplement("supplement_2 ", 1);
        Supplement supplement_3 = new Supplement("supplement_3 ", 1);
        supplements.add(supplement_3);
        supplements.add(supplement_2);
        supplements.add(supplement_1);

        Magazine magazine_1 = new Magazine("Magazine_1", 1, new ArrayList<>());
        Magazine magazine_2 = new Magazine("Magazine_2", 1, new ArrayList<>());
        Magazine magazine_3 = new Magazine("Magazine_3", 1, new ArrayList<>());
        magazines.add(magazine_1);
        magazines.add(magazine_2);
        magazines.add(magazine_3);
        List<Customer> associateCustomerList = new ArrayList<>();
        Customer john = new Customer("John", "john.smith@example.com", new ArrayList<>(), new ArrayList<>());
        Customer alice = new Customer("Alice", "alice.jones@example.com", new ArrayList<>(), new ArrayList<>());
        Customer robert = new Customer("Robert", "robert.williams@example.com", new ArrayList<>(), new ArrayList<>());
        associateCustomerList.add(john);
        associateCustomerList.add(alice);
        associateCustomerList.add(robert);
        PayingCustomer.PaymentMethod selectedPaymentMethod = PayingCustomer.PaymentMethod.CREDIT_CARD;
        PayingCustomer sarah = new PayingCustomer(selectedPaymentMethod, "UK Bank", associateCustomerList, "Sarah", "sarah@gmail.com", new ArrayList<>(), new ArrayList<>());
        payingCustomers.add(sarah);

        Customer johnjohn = new Customer("johnjohn", "john.smith@example.com", new ArrayList<>(), new ArrayList<>());
        Customer alicealice = new Customer("Alicealisce", "alice.jones@example.com", new ArrayList<>(), new ArrayList<>());
        Customer robertrober = new Customer("Robertrobert", "robert.williams@example.com", new ArrayList<>(), new ArrayList<>());
        associateCustomers.add(johnjohn);
        associateCustomers.add(alicealice);
        associateCustomers.add(robertrober);
    }

    /**
     * Returns the list of paying customers.
     *
     * @return The list of paying customers.
     */
    public List<PayingCustomer> getPayingCustomers() {
        return payingCustomers;
    }

    /**
     * Sets the list of paying customers.
     *
     * @param payingCustomers The list of paying customers.
     */
    public void setPayingCustomers(List<PayingCustomer> payingCustomers) {
        this.payingCustomers = payingCustomers;
    }

    /**
     * Returns the list of associate customers.
     *
     * @return The list of associate customers.
     */
    public List<Customer> getAssociateCustomers() {
        return associateCustomers;
    }

    /**
     * Sets the list of associate customers.
     *
     * @param associateCustomers The list of associate customers.
     */
    public void setAssociateCustomers(List<Customer> associateCustomers) {
        this.associateCustomers = associateCustomers;
    }

    /**
     * Returns the list of supplements.
     *
     * @return The list of supplements.
     */
    public List<Supplement> getSupplements() {
        return supplements;
    }

    /**
     * Sets the list of supplements.
     *
     * @param supplements The list of supplements.
     */
    public void setSupplements(List<Supplement> supplements) {
        this.supplements = supplements;
    }

    /**
     * Returns the list of magazines.
     *
     * @return The list of magazines.
     */
    public List<Magazine> getMagazines() {
        return magazines;
    }

    /**
     * Sets the list of magazines.
     *
     * @param magazines The list of magazines.
     */
    public void setMagazines(List<Magazine> magazines) {
        this.magazines = magazines;
    }

    /**
     * Adds a supplement to the database.
     *
     * @param supplement The supplement to add.
     */
    public void addSupplement(Supplement supplement) {
        supplements.add(supplement);
    }

    /**
     * Removes a supplement from the database.
     *
     * @param supplement The supplement to remove.
     */
    public void removeSupplement(Supplement supplement) {
        supplements.remove(supplement);
    }

    /**
     * Adds a magazine to the database.
     *
     * @param magazine The magazine to add.
     */
    public void addMagazine(Magazine magazine) {
        magazines.add(magazine);
    }

    /**
     * Removes a magazine from the database.
     *
     * @param magazine The magazine to remove.
     */
    public void removeMagazine(Magazine magazine) {
        magazines.remove(magazine);
    }

    /**
     * Adds a paying customer to the database.
     *
     * @param payingCustomer The paying customer to add.
     */

    public void addPayingCustomer(PayingCustomer payingCustomer) {
        payingCustomers.add(payingCustomer);
    }

    /**
     * Removes a paying customer from the database.
     *
     * @param payingCustomer The paying customer to remove.
     */
    public void removePayingCustomer(PayingCustomer payingCustomer) {
        payingCustomers.remove(payingCustomer);
    }

    /**
     * Adds an associate customer to the database.
     *
     * @param associateCustomer The associate customer to add.
     */
    public void addAssociateCustomer(Customer associateCustomer) {
        associateCustomers.add(associateCustomer);
    }

    /**
     * Removes an associate customer from the database.
     *
     * @param associateCustomer The associate customer to remove.
     */
    public void removeAssociateCustomer(Customer associateCustomer) {
        associateCustomers.remove(associateCustomer);
    }

    /**
     * Allows the user to select a magazine from the database.
     *
     * @return The selected magazine.
     */
    public Supplement selectSupplement() {
        System.out.println("Available Supplements:");
        displayItems(supplements);
        int selection = getUserSelection("Enter the index of the supplement to select: ", supplements.size());
        return supplements.get(selection - 1);
    }

    public Magazine selectMagazine() {
        System.out.println("Available Magazines:");
        displayItems(magazines);
        int selection = getUserSelection("Enter the index of the magazine to select: ", magazines.size());
        return magazines.get(selection - 1);
    }

    private void displayItems(List<?> items) {
        for (int i = 0; i < items.size(); i++) {
            String itemName = "";
            if (items.get(i) instanceof Supplement) {
                itemName = getSupplementName(i);
            } else if (items.get(i) instanceof Magazine) {
                itemName = getMagazineName(i);
            }
            System.out.println((i + 1) + ". " + itemName);
        }
    }

    private int getUserSelection(String prompt, int size) {
        Scanner scanner = new Scanner(System.in);
        int selection = 0;
        boolean validInput = false;
        while (!validInput) {
            try {
                System.out.print(prompt);
                selection = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                if (selection >= 1 && selection <= size) {
                    validInput = true;
                } else {
                    System.out.println("Invalid selection. Please enter a number between 1 and " + size + ".");
                }
            } catch (InputMismatchException e) {
                scanner.nextLine(); // Consume invalid input
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        return selection;
    }

    /**
     * Returns the name of the magazine at the specified index.
     *
     * @param index The index of the magazine.
     * @return The name of the magazine.
     */
    public String getMagazineName(int index) {
        if (index >= 0 && index < magazines.size()) {
            return magazines.get(index).getMagazineName();
        }
        return null;
    }

    /**
     * Returns the name of the supplement at the specified index.
     *
     * @param index The index of the supplement.
     * @return The name of the supplement.
     */
    public String getSupplementName(int index) {
        if (index >= 0 && index < supplements.size()) {
            return supplements.get(index).getSupplementName();
        }
        return null;
    }

}
