module com.mycompany.assignment2v2 {
    requires javafx.controls;
    exports com.mycompany.assignment2v2;
}
